#!/bin/bash
cd "$(dirname "$0")"

# --- Змінні для зручності ---
FORGE_VER="10.13.4.1614"
FORGE_JAR="forge-1.7.10-$FORGE_VER-1.7.10-universal.jar"
INSTALLER_JAR="forge-1.7.10-$FORGE_VER-1.7.10-installer.jar"
PACKWIZ_JAR="packwiz-installer-bootstrap.jar"
PACK_URL="https://raw.githubusercontent.com/4iki40k/NULP-linux-minecraft/main/pack.toml"
JAVA_CMD="/usr/lib/jvm/java-8-openjdk/jre/bin/java"

# 1. Перевірка та встановлення Forge
if [ ! -f "$FORGE_JAR" ]; then
    echo "--- Ядро Forge не знайдено. Починаю встановлення... ---"
    wget -q --show-progress "https://maven.minecraftforge.net/net/minecraftforge/forge/1.7.10-$FORGE_VER-1.7.10/$INSTALLER_JAR"
    $JAVA_CMD -jar "$INSTALLER_JAR" --installServer
    rm "$INSTALLER_JAR" # Видаляємо інсталятор після встановлення
    rm "$INSTALLER_JAR.log"
fi

# 2. Перевірка та завантаження Packwiz Bootstrap
if [ ! -f "$PACKWIZ_JAR" ]; then
    echo "--- Packwiz Installer не знайдено. Завантажую... ---"
    wget -q --show-progress "https://github.com/packwiz/packwiz-installer-bootstrap/releases/latest/download/$PACKWIZ_JAR"
fi

# 3. Автоматичне прийняття EULA
if [ ! -f "eula.txt" ] || ! grep -q "eula=true" "eula.txt"; then
    echo "--- Автоматичне прийняття EULA... ---"
    echo "eula=true" > eula.txt
fi

# 4. Синхронізація модів з GitHub
echo "--- Синхронізація модів (Packwiz)... ---"
$JAVA_CMD -jar "$PACKWIZ_JAR" -g -s server "$PACK_URL"

# 5. Фінальний запуск сервера
echo "--- Запуск сервера... ---"
$JAVA_CMD -Xms2G -Xmx4G -jar "$FORGE_JAR" nogui
